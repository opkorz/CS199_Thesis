evaluate_performance(net, err)
BPNN *net;
double *err;
{
  int ctr;
  double delta;

  delta = net->target[1] - net->output_units[1];

  *err = (0.5 * delta * delta);

  /*** If the target unit is on... ***/
  if (net->target[1] > 0.5) {

    /*** If the output unit is on, then we correctly recognized me! ***/
    if (net->output_units[1] > 0.5) {
      return (1);

    /*** otherwise, we didn't think it was me... ***/
    } else {
      return (0);
    }

  /*** Else, the target unit is off... ***/
  } else {

    /*** If the output unit is on, then we mistakenly thought it was me ***/
    if (net->output_units[1] > 0.5) {
      return (0);

    /*** else, we correctly realized that it wasn't me ***/
    } else {
      return (1);
    }
  }

}


for( ctr=1; ctr<7; ctr++){
  delta = net->target[ctr] - net->output_units[ctr];

  *err = (0.5 * delta * delta);

  /*** If the target unit is on... ***/
  if (net->target[ctr] > 0.5) {

    /*** If the output unit is on, then we correctly recognized me! ***/
    if (net->output_units[ctr] > 0.5) {
      return (ctr);

    /*** otherwise, we didn't think it was me... ***/
    } else {
      return (0);
    }

  /*** Else, the target unit is off... ***/
  } else {

    /*** If the output unit is on, then we mistakenly thought it was me ***/
    if (net->output_units[ctr] > 0.5) {
      return (0);

    /*** else, we correctly realized that it wasn't me ***/
    } else {
      return (1);
    }
  }
}

